@echo off
mode 32,12
title Timer
cd resource
:home
cls
echo choose...
cmdmenusel cff2 "begin timer" "open calculator" "exit"
if %errorlevel% == 1 goto start
if %errorlevel% == 2 start calc
if %errorlevel% == 3 exit
goto home

:start
title Enter your time

cls
echo Enter time to countdown from...
echo.
echo or type back/b to go back 
echo to the main menu.
echo.
set/p "time=>"
if %time% == b goto home
if %time% == back goto home
for /f "delims=0123456789" %%a in ("%time%") do (
echo.
    echo Invalid input. 
echo Please enter a number.
echo.
    pause 
    goto start
)
set time=%time%

:loop
cls

set /a time=%time%-1
if %time%==0 goto timesup

title Counting down...

echo.
echo.

echo.
echo Countdown - [%time%]

timeout /t 1 > nul
goto loop

:timesup
echo Time is Up!!
start systemTrayNotification.bat   -tooltip info -time 5000 -title "Time counter" -text "Your time is up! -icon 
ffplay -loop -1 loud_alarm.mp3
echo.
echo.
pause
goto start