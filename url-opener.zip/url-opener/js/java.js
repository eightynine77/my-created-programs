function button1(){
var input = document.getElementById("inputfieldjs").value; 
  var urlRegex = /(https?:\/\/[^\s]+)/g; 
  
  var matches = input.match(urlRegex); 
  
  if (matches) {
    for (var i = 0; i < matches.length; i++) {
      window.open(matches[i], '_blank');
    }
  } else {
    window.open("https://" + input, '_blank')
  }
}

document.addEventListener('DOMContentLoaded', () => {
    let input = document.getElementById('inputfieldjs');
  
    if (input) {
      input.addEventListener('keyup', (e) => {
        if (e.keyCode === 13) {
            var input22 = document.getElementById("inputfieldjs").value; 
  var urlRegex22 = /(https?:\/\/[^\s]+)/g; 
  
  var matches22 = input22.match(urlRegex22); 
            if (matches22) {
                for (var i = 0; i < matches22.length; i++) {
                  window.open(matches22[i], '_blank');
                }
              } else {
                window.open("https://" + input22, '_blank')
              }
        }
      });
    }
  });  

function clearthetext(){
    document.getElementById('inputfieldjs').value = ''
}

function addhttps(){
var https1 = 'https://'
var userinput = document.getElementById('inputfieldjs').value
document.getElementById('inputfieldjs').value = (https1 + userinput);
} 