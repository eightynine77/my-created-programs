@echo off
:host
cls
color f
mode con: cols=75 lines=10
title File maker
echo choose witch file you wanna make
echo.
echo Note: make sure if you want to make a file you have to name it different
echo.
echo [1]Batch  [3] txt   [5]exit
echo [2]VBS    [4]diary
echo.
choice /c 12345 /n /m "choose:"
if  errorlevel == 5 goto Exit
if  errorlevel == 4 goto diary 
if  errorlevel == 3 goto txt
if  errorlevel == 2 goto vbs 
if  errorlevel == 1 goto batch
goto host

:batch
pushd\ & pushd users & pushd %userprofile%\desktop 
cls
color f
echo name your batch program
echo =======================
set /p "id=name:"
echo @echo off > "%id%.bat"
echo :host >> "%id%.bat"
echo cls >> "%id%.bat"
echo color >> "%id%.bat"
echo goto host >> "%id%.bat"
echo your batch program has succesfuly created... check your desktop
pause
popd
goto host

:vbs
pushd\ & pushd users & pushd %userprofile%\desktop 
cls
color f
echo name your VBS program
echo =====================
set /p "tag=name:"
echo . > "%tag%.vbs" 
echo your VBS program has succesfuly created... check your desktop
pause
goto host

:txt
pushd\ & pushd users & pushd %userprofile%\desktop 
cls
color f
echo name your Text file
echo ===================
set /p "tag=name:"
echo . > "%tag%.txt"
echo your text file has been succesfuly created... check your desktop
pause
goto host

:Diary
pushd\ & pushd users & pushd %userprofile%\desktop 
cls
color f
echo name your Diary
echo ===============
set /p "Dia=name:"
echo .LOG > "%Dia%.txt"
echo your Diary has been succesfuly created... check your desktop
pause
goto host

:Exit
exit