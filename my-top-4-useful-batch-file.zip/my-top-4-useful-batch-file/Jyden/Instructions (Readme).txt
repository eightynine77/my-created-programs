hello fellow users :)

my name is Jebbidan. and i created this program 

my Youtube channel: https://www.youtube.com/channel/UCUExIxwV3Nc1yLxQV74CqXw

please subscribe :)

====================================================================================

i will show to you which is the right version for your windows PC

there are two version: 32-bit version and 64-bit version

so how to check which bits does your windows PC have?

well it's simple

just open FileExplorer. you can do that by just simply open the Recycle Bin

copy and paste this Directory on file explorer adress bar (directory bar)

Control Panel\System and Security\System



and there you go you now know how many Bits does your windows PC have and which version of Jyden that you want to open

================================================================================================================================
making your web browser Jyden compatible
================================================================================================================================


you might realise that the search feature can't be used

well don't worry here is how you can make it compatible

see this?

@echo off 
:host 
cls 
color f
mode con: cols=40 lines=15
cls
title search
echo type wwhat you want to search
echo like this:
echo how to do the dew
echo how+to+do+the+dew
echo the space is +
set /p "search=search:"
cd "C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application"
brave http://www.google.pt/search?q=%search%
goto host 

this is the program extension source code (in batch). this is how you gonna make it compatible

(basicaly you edit the batch file extension source code)
the name of batch file is cari

======================================================================================================

@echo off 
:host 
cls 
color f
mode con: cols=40 lines=15
cls
title search
echo type wwhat you want to search
echo like this:
echo how to do the dew
echo how+to+do+the+dew
echo the space is +
set /p "search=search:"
cd "[put your browser directory / path here]"
[your browser name] http://www.google.pt/search?q=%search%
goto host 

well for example...

@echo off 
:host 
cls 
color f
mode con: cols=40 lines=15
cls
title search
echo type wwhat you want to search
echo like this:
echo how to do the dew
echo how+to+do+the+dew
echo the space is +
set /p "search=search:"
cd "C:\Program Files (x86)\chrome"
chrome http://www.google.pt/search?q=%search%
goto host 

----------------------------------------------------------------------------------------------------------------------------------------
BEFORE:                                                                                    
  
@echo off 
:host 
cls 
color f
mode con: cols=40 lines=15
cls
title search
echo type wwhat you want to search
echo like this:
echo how to do the dew
echo how+to+do+the+dew
echo the space is +
set /p "search=search:"
cd "C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application"
brave http://www.google.pt/search?q=%search%
goto host 

----------------------------------------------------------------------------------------------------------------------------------------
AFTER:      

@echo off 
:host 
cls 
color f
mode con: cols=40 lines=15
cls
title search
echo type wwhat you want to search
echo like this:
echo how to do the dew
echo how+to+do+the+dew
echo the space is +
set /p "search=search:"
cd "C:\Program Files (x86)\chrome"
chrome http://www.google.pt/search?q=%search%
goto host                                 



