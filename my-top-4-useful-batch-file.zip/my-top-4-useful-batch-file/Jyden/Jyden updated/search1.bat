@echo off 
:a 
cls 
color f
title search  
mode 1000
echo NOTE: this only works if you have the brave browser. make sure you download it.
echo                       but if you want to use the different browser
echo                  you can edit the code don't wory it would be easy
echo                             all you have to do is to copy and paste your browser directory (by locating where is your browser)
echo              and but it on the text file named 
echo                                            search-copy&paste_me
echo.
echo Type what you want to search 
echo.
echo Put  + where you put the spaces
echo.
echo You want to search.
echo Would be:
echo you+want+to+search
set /p "search=search:"
cd "C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application"
brave http://www.google.pt/search?q=%search%
goto a