@echo off
:startscreen
start ohyeah.vbs
color f
mode 1000
title Jyden V 2.0
cls
type Intro.txt
timeout /t 3 /nobreak >nul
goto host

:host
@echo off
cls
color f0
mode 1000
title Jyden v 2.0
echo.                                  ___________   ________
echo ***    ***  ***    *** ********* *           * *        *
echo * *   * *   * *    * * *       * * **** **** * * ****** * 
echo * *  * *    * *    * * *  OOO  * * *  * *  * * * *    * *
echo * *** *     * *    * * *       * * *  ***  * * * ****** *
echo * *** *     * *    * * * ******* * *       * * * *    * *
echo * *  * *    * *____* * * *OOO    * *       * * * *    * *
echo * *   * *   *        * * * OOO   * *       * * * *    * * 
echo ***    ***  ********** ***  OOO  ***       *** ***    ***  
echo.
echo welcome to Jyden dirrect web opener
echo made by Kurma corp
echo. 
echo type the number that had already been shown on the screen and press [ENTER] button 
echo. 
echo choose...
echo.
     echo 1) Sign in
     echo 2) Log-in
     echo 3) exit to windows
     echo 4) Retry the Intro 
echo.
echo choose by presing the number on your keyboard that was already been shown on the program
choice /c 1234 /n  
        if errorlevel 4 goto startscreen
	if errorlevel 3 goto exit3
    	if errorlevel 2 goto log2 
    	if errorlevel 1 goto sign1
goto host

:sign1
cls
color f
title Jyden v 2.0\Sign-in screen
echo Type your username...
echo.
echo if you unpurposley choose this option then you have to close the window 
echo (it's the only way)
echo.
set /p USERNAME= \Username\:
set /p PASSWORD= \Password\:
echo %USERNAME% >> A1b2a.txt
echo %PASSWORD% >> 3fba0.txt
echo Your account has successfuly created...
echo.
echo press any key to go back...
pause >nul
goto host

:log2
cls
color f
title Jyden v 2.0\Log-in screen
echo type your password to Log-in...
echo.
echo to go back close the program
echo (it's the only way)
set /p PASSWORD1= \Password\: 

for /f "Delims=" %%a in (3fba0.txt) do (

set TEXT=%%a

)

if %PASSWORD1%==%TEXT% goto correct2
cls
echo wrong password access denied!...
echo.
echo maybe you haven't made your account yet or you forgot your password
echo.
echo press any key to go back...
pause >nul
goto host

:exit3
exit

:correct2
cls
color 04
title Jyden v 2.0\
echo Welcome :) 
echo. 
echo           `-:/+oo+/:-`                       `.:/+oo++/-.                                      
echo        `:ossyyyyyyyyss+-`                  -+ssyyyyyyyysso/.                                   
echo      `/ssyyyyyyyyyyyyyyso-               -osyyyyyyyyyyyyyyys/`                                 
echo     `osyyyyyyyyyyyyyyyyyys/             :syyyyyyyyyyyyyyyyyyyo.                                
echo    `oyyyyyyyyyyyyyyyyyyyyys/           :syyyyyyyyyyyyyyyyyyyyys`                               
echo    :yyyyyyyyyyyyyyyyyyyyyyys.         `syyyyyyyyyyyyyyyyyyyyyyy/                               
echo    oyyyyyyyyyyyyyyyyyyyyyyyy/         -yyyyyyyyyyyyyyyyyyyyyyyys                                
echo    ohddddhyyyyyyyyyyyyhddddh/         -hmmmmdyyyyyyyyyyyyyhmmmms                               
echo    :mMMMMMhyyyyyyyyyydMMMMMh.         `yMMMMMhyyyyyyyyyyyymMMMN+                               
echo    `sNMMMMMdhhyyyyyydMMMMMm+           /dMMMMMmhyyyyyyyyhmMMMMy.                               
echo     .sNMMMMMMMNNNNNNMMMMMmo`            /dMMMMMMNmddddmNMMMMNh-                                
echo      `+dNMMMMMMMMMMMMMMNh/`              -yNMMMMMMMMMMMMMMMmo.                                 
echo        .+hmNMMMMMMMMNmy/`                 `:sdNMMMMMMMMNNho-                                   
echo          `./osyyyys+:.`                      .:+osyyyso/-`                                     
echo                ``                                 ``                                           
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo              .                                   `::                                          
echo               /o:.``                          `.-o/-                                           
echo                 .-:///-.....           .....-:+//:-                                              
echo                      `.-::::::::::::::::::-`              
echo.
echo Jyden (the figure you see now) says: scroll up please... do it if you're in small window mode
echo.
echo press any key to conitnue...
pause >nul
goto menu1

:menu1
cls
color f
title Jyden the dirrect web opener V 2.0
echo                                                                       *******************************************
echo           `-:/+oo+/:-`                       `.:/+oo++/-.             *  hello users my name is Jyden           *                
echo        `:ossyyyyyyyyss+-`                  -+ssyyyyyyyysso/.          *  and i will be your Digital assistance  *             
echo      `/ssyyyyyyyyyyyyyyso-               -osyyyyyyyyyyyyyyys/`        *  the list is the stuff i can do         *          
echo     `osyyyyyyyyyyyyyyyyyys/             :syyyyyyyyyyyyyyyyyyyo.       *  also i can sing                        *       
echo    `oyyyyyyyyyyyyyyyyyyyyys/           :syyyyyyyyyyyyyyyyyyyyys`     **  would you like to hear it?             *                        
echo    :yyyyyyyyyyyyyyyyyyyyyyys.         `syyyyyyyyyyyyyyyyyyyyyyy/    ******************  press the button [4]    *                  
echo    oyyyyyyyyyyyyyyyyyyyyyyyy/         -yyyyyyyyyyyyyyyyyyyyyyyys   *****              *  to tell me to sing     * 
echo    ohddddhyyyyyyyyyyyyhddddh/         -hmmmmdyyyyyyyyyyyyyhmmmms  ***                  **************************           
echo    :mMMMMMhyyyyyyyyyydMMMMMh.         `yMMMMMhyyyyyyyyyyyymMMMN+                               
echo    `sNMMMMMdhhyyyyyydMMMMMm+           /dMMMMMmhyyyyyyyyhmMMMMy.                               
echo     .sNMMMMMMMNNNNNNMMMMMmo`            /dMMMMMMNmddddmNMMMMNh-                                
echo      `+dNMMMMMMMMMMMMMMNh/`              -yNMMMMMMMMMMMMMMMmo.                                 
echo        .+hmNMMMMMMMMNmy/`                 `:sdNMMMMMMMMNNho-                                   
echo          `./osyyyys+:.`                      .:+osyyyso/-`                                     
echo                ``                                 ``                                           
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo.                                                                                                    
echo              .                                   `::                                          
echo               /o:.``                          `.-o/-                                           
echo                 .-:///-.....           .....-:+//:-                                              
echo                      `.-::::::::::::::::::-`
echo.
echo .........................................................................................................     
echo :///////////////////////////////////////////////////////////////////////////////////////////////////////:
echo.
echo [3] Open websites
echo [2] Search websites
echo [1] Log-out
echo.
echo choose the option by pressing the number button that was already shown on the program's window (screen)
choice /c 1234 /n
if errorlevel 4 goto singtime
if errorlevel 3 goto openb
if errorlevel 2 goto malarki
if errorlevel 1 goto host
goto menu1

:singtime
taskkill /f /im wscript.exe
cls
title Jyden v 2.0\Jyden sing a song
echo.       
echo.  
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo                                                                      *
echo ------------------------------------------------------------[        ***        ]---------------------------------------------------------------
echo                                                                      *
echo.
echo.
echo. 
choice /c 12 /n /m "press the [2] button to tell Jyden to sing. press the button [1] to go back"
if errorlevel 2 goto Jydensing 
if errorlevel 1 goto menu1
goto singtime

:Jydensing
set "file=Daisy_Bell_IBM.m4a"
( echo Set Sound = CreateObject("WMPlayer.OCX.7"^)
  echo Sound.URL = "%file%"
  echo Sound.Controls.play
  echo do while Sound.currentmedia.duration = 0
  echo wscript.sleep 100
  echo loop
  echo wscript.sleep (int(Sound.currentmedia.duration^)+1^)*1000) >sound.vbs
start /min sound.vbs
cls
color f
echo.       
echo.  
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo.
echo                                                                     ** **
echo ------------------------------------------------------------[       ** **       ]---------------------------------------------------------------
echo                                                                     ** **
echo.
echo.
echo.
echo press any key to tell Jyden to stop singing...
pause >nul
goto singtime

:openb
	 cls
	   color f
		 title Jyden v 2.0\direct website opener  
			 echo hello %username% :)
                         echo.
		         echo my creator Jebbidan has created me to know who you're :)
			 echo. 
			 echo pretty cool right? :)
			 echo.
                         echo type B / b to go back when the go back option pop-up came after you opened a website
echo.
set /p SWO= website:
	 start www.%SWO%.com
set /p back= press [B / b] to go back: 
if %back%== B goto menu1
if %back%== b goto menu1
goto openb

:malarki
cls
color f
echo are you sure you already make your search engine compatible with this program?
echo ------------------------------------------------------------------------------
choice /c 12 /n /m "[1]Yes [2]No"
if errorlevel 2 goto menu1
if errorlevel 1 start search1.bat
goto malarki








