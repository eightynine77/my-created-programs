@echo off 
:host
cd "C:\Users\salma\Programs file\BraveSoftware\Brave-Browser\Application" 
cls 
color f
mode con: cols=40 lines=15
cls
title search
echo type wwhat you want to search
echo like this:
echo how to do the dew
echo how+to+do+the+dew
echo the space is +
echo.
set /p "open=type the [D] to start browser:"
if %open%== D start brave.exe
if %open%== d start brave.exe
set /p "search=search:"
brave http://www.google.pt/search?q=%search%
goto host 
