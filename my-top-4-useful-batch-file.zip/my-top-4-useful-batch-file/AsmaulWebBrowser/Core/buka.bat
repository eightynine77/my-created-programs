@echo off 
:host 
cd "C:\Users\salma\Programs file\BraveSoftware\Brave-Browser\Application"
cls 
color f
mode con: cols=40 lines=15
title open
echo type the website's name
echo.
set /p "open=type the [D] to start browser:"
if %open%== D start brave.exe
if %open%== d start brave.exe
set /p "website=website:"
brave www.%website%.com
goto host 
