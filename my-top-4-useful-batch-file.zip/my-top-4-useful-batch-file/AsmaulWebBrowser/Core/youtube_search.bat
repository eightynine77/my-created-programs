@echo off 
:host 
mode con: cols=40 lines=15
cd "C:\Users\salma\Programs file\BraveSoftware\Brave-Browser\Application"
cls 
color f
title youtube search
echo youtube search
echo.
set /p "open=type the [D] to start browser:"
if %open%== D start brave.exe
if %open%== d start brave.exe
set /p "ys=Youtube search:"
brave https://www.youtube.pt/results?search_query=%ys%
goto host 
