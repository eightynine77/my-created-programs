@echo off 
cd core
:bom
cls
mode con: cols=54 lines=15
title instant web opener
echo choose
cmdmenusel "a" "instant search" "manual search" "open" "youtube search"
if %errorlevel%== 1 goto an
if %errorlevel%== 2 goto manual
if %errorlevel%== 3 goto c
if %errorlevel%== 4 goto youtube
goto bom

:an
start cari.bat
goto bom

:manual
start manual_search.bat
goto bom

:c 
start buka.bat
goto bom

:youtube
start youtube_search.bat
goto bom