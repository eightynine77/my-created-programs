@echo off 
:folder   
cd\ & cd users & cd %userprofile%\desktop 
cls
color f
mode con: cols=70 lines=15
title folder maker
echo put where your folder is gonna be made
echo.
echo [1] Desktop
echo [2] Documents
echo [3] Downloads
echo [4] Music
echo [5] Pictures
echo [6] Videos
echo [7] custom directory
echo [8] Local Disk C:\ (need to run as admin)
echo.
choice /c 12345678 /n
if errorlevel 8 goto C 
if errorlevel 7 goto custom
if errorlevel 6 goto v 
if errorlevel 5 goto p 
if errorlevel 4 goto m
if errorlevel 3 goto d
if errorlevel 2 goto doc
if errorlevel 1 goto des
goto folder


:des
cd\ & cd users & cd %userprofile%\desktop
cls
color f0
echo name your folder
echo ================
set /p "folder=name:"
md "%folder%"
echo your folder has been succesfuly created... check your desktop
pause
goto folder

:doc
cd\ & cd users & cd %userprofile%\Documents
cls
color f0
echo name your folder
echo ================
set /p "folder=name:"
md "%folder%"
echo your folder has been succesfuly created... check your document folder
pause
goto folder

:d
cd\ & cd users & cd %userprofile%\downloads
cls
color f0
echo name your folder
echo ================
set /p "folder=name:"
md "%folder%"
echo your folder has been succesfuly created... check your download folder
pause
goto folder

:m
cd\ & cd users & cd %userprofile%\music
cls
color f0
echo name your folder
echo ================
set /p "folder=name:"
md "%folder%"
echo your folder has been succesfuly created... check your music folder
pause
goto folder

:p
cd\ & cd users & cd %userprofile%\pictures
cls
color f0
echo name your folder
echo ================
set /p "folder=name:"
md "%folder%"
echo your folder has been succesfuly created... check your Picture folder
pause
goto folder

:v
cd\ & cd users & cd %userprofile%\videos
cls
color f0
echo name your folder
echo ================
set /p "folder=name:"
md "%folder%"
echo your folder has been succesfuly created... check your  video folder
pause
goto folder

:custom
cd\
cls
color f0
echo type the directory or just copy and paste the directory
echo =======================================================
set /p "dir=directory:"
cd %dir%
echo.
echo name your folder
echo ================
set /p "folder=name:"
md "%folder%"
echo your folder has been succesfuly created... check your directory
pause
goto folder

:C
cd\
cls
color f0
echo name your folder
echo ================
set /p "folder=name:"
md "%folder%"
echo your folder has been succesfuly created... check your C:\ drive
pause
goto folder