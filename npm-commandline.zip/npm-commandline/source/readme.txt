if you want to turn the source file (npm-cli.src file) into a working file you can use then
change the file extension of npm-cli.src to npm-cli.bat and move npm-cli.bat to the root directory 
of npm-cli