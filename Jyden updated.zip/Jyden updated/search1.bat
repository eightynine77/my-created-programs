@echo off 
:a 
cls 
color f
title search  
mode con: cols=80 lines=15
echo NOTE: if you want to use the feature make sure you read the instruction FIRST
echo to see if this feature is compatible with your webbrowser
echo.
echo Type what you want to search 
echo.
echo use the + sign as spaces
echo.
echo your search Would be like this:
echo BEFORE: you want to search 
echo AFTER: you+want+to+search
set /p search=search:
cd "C:\Program Files (x86)\Microsoft\Edge\Application"
msedge http://www.google.pt/search?q=%search%
goto a