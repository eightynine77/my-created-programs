@echo off
setlocal EnableDelayedExpansion EnableExtentions
:game
cls
mode 1000
color f0
cd textures
title Gangster mafia - made by Jebbidan
type OpeningScreen.txt
echo.
echo -press any key to skip intro-
cd..
cd music
start OpeningScreen.vbs
timeout /t 8 >nul
goto MainMenu

:MainMenu
taskkill /f /im wscript.exe
Cls 
cd..
cd textures
cls
color f0
type MainMenu.txt
echo.
Echo.
echo [1]Start 
echo [2]Help 
echo [3]Info
echo [4]Exit 
choice /c 1234 /n /m "choose:"
if errorlevel 4 goto quit
if Errorlevel 3 goto info
if Errorlevel 2 goto help
if Errorlevel 1 goto Start 
goto mainmenu

:start
cd..
cd components\AccountSystem
accountsystem.bat


:help
cls
color f
title help screen
echo just press the number keys that appears on this game...
echo.
echo -press any key to go back-
Pause>nul
goto mainmenu


:info
cls
echo made by Jebbidan
echo.
echo let's subscribe to my channel... shall we >_^
echo.
echo my youtube channel :  https://urlzs.com/rS6Wk
echo my website         :  https://urlzs.com/m5QsH
echo.
echo -press any key to go back into the main screen-
pause >nul          
goto mainmenu

:quit
taskkill /f /im wscript.exe
exit



