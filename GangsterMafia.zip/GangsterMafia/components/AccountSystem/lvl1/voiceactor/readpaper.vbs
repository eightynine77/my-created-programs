dim speechobject
set speechobject=createobject("sapi.spvoice")
speechobject.speak "Great. now the boss has gone totally insane"