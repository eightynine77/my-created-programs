@echo Off
setlocal EnableDelayedExpansion EnableExtentions
:menu
cls
mode 1000
title Gangster mafia - made by Jebbidan
echo Log-in/Sign-in screen
echo.
echo 1.) Create Account
echo 2.) log-in
echo.
choice /c 12 /n /m "Choose:"
if Errorlevel 2 goto load
if Errorlevel 1 goto create
goto menu

:create
cls
echo Create An Account!!
echo.
echo WARNING! you must create your name first
Echo.
echo to make things clear: create your name first, your password second, and crate your account is the finnal step
echo 1.) Set Name
echo 2.) Set Password
echo 3.) Create Account
echo 4.) Go back
echo.
choice /c 1234 /n /m "choose:"
if Errorlevel 4 goto menu
if Errorlevel 3 goto createaccount
if Errorlevel 2 Goto setpassword
if Errorlevel 1 goto setname
goto create

:setname
cls
echo enter your name
echo.
set /p name="Enter: "
goto setpassword

:setpassword
cls
echo enter your password
echo.
set /p password="Enter: "
goto createaccount

:createaccount
cls
echo enter your confirmation name
set /p savename="Enter: "
cls
echo Saving Account...
(
echo %name%
echo %password%
) > .\accounts\%savename%.sav
cls
echo Account Saved!
pause
goto menu

:load
cls
echo Enter your confirmation name
echo.
set /p entername="Enter: "
if not exist .\accounts\"%entername%".sav (
echo Account Name %entername% does not exist.
pause >nul
goto load
)
< .\accounts\%entername%.sav (
set /p name=
set /p password=
)
cls
echo What is the password for the account named %name%
echo.
set /p enterpass="Enter: "
if not "%enterpass%" equ "%password%" goto wrongpass
goto login

:wrongpass
cls
echo That is the the incorrect password for the account named %name%
set name=
set password=
pause >Nul
goto load

:login
cls
echo Logging in...
< .\accounts\%savename%.sav (
set /p name=
set /p password=
)
cls
goto escape

:escape
cls
echo welcome %name%
echo.
pause
goto startthisgame

:startthisgame
@Echo off
Cls
color f0
cd lvl1\textures
echo press any key to skip this cutscene
Echo.
Echo.
type passout.txt
timeout /t 0 >Nul
cls
echo press any key to skip this cutscene
Echo.
Echo.
type passout2.txt
timeout /t 0 >Nul
cls
echo press any key to skip this cutscene
Echo.
Echo.
type passout3.txt
timeout /t 0 >Nul
cls
echo press any key to skip this cutscene
Echo.
Echo.
type headhurts.txt
timeout /t 3 >Nul
goto game

:game
taskkill /f /im wscript.exe
cd..
cd textures
cls
color f0
type office.txt
echo.
choice /c 123 /n /m "choose:"
if errorlevel 3 goto shit
if errorlevel 2 goto door
if errorlevel 1 goto paper
goto game

:paper
Cls
type paper.txt
echo.
echo press any keys to skip this cutscene...
cd..
cd voiceactor
start readpaper.vbs
timeout /t 5 >Nul
goto game

:door
cd..
cd textures
Cls
type door.txt
Echo.
choice /c 12 /n /m "choose:"
if errorlevel 2 goto game
if errorlevel 1 goto pin
goto door

:pin
cls
type pin.txt
echo.
set /p "cho=choice:"
if  %cho%== 1680 goto correct
if  %cho%== cancel goto door
goto invalid

:correct
cls
type pswrdcorrect.txt
Echo.
pause
goto lvl2

:invalid
Cls
type pswrdincorrect.txt
Echo.
pause
goto pin

:shit
cls
type deskcabinet.txt
Echo.
choice /c 1234 /n /m "choice:"
if Errorlevel 4 goto game
if Errorlevel 3 goto eat
if Errorlevel 2 goto takegun
if Errorlevel 1 goto phone
goto desk

:phone
cls
type usephone.txt
echo.
choice /c 1234 /n /m "choose:"
if errorlevel 3 goto shit
if errorlevel 2 goto sms
if errorlevel 1 goto filemanager
goto phone

:filemanager
cls
type PhoneExplorer.txt
echo.
choice /c 1234567 /n /m "choice:"
if errorlevel 7 goto phone
if errorlevel 6 goto favs
if errorlevel 5 goto music
if errorlevel 4 goto docs
if errorlevel 3 goto vids
if errorlevel 2 goto notes
if errorlevel 1 goto pics
goto filemanager

:pics
cls
type PhonePicture.txt
echo.
choice /c 12345678 /n /m "choose:"
if errorlevel 8 goto filemanager
if errorlevel 7 goto scroll
if errorlevel 6 goto beautiful
if errorlevel 5 goto gf
if errorlevel 4 goto data
if errorlevel 3 goto time
if errorlevel 2 goto goat
if errorlevel 1 goto mount
goto pics

:mount
cls

:goat

:time

:data

:gf

:beautiful

:scroll
cls
type ScrollPicturePhone.txt
echo.
choice /c 123 /n /m


:notes

:vids

:docs

:music

:favs

:sms
Cls
pause
exit

:takegun
cls
type takegun.txt
timeout /t 1 /nobreak >nul
goto desk

:eat
cls
type takesnacks.txt
timeout /t 1 /nobreak >nul
type eatsnacks.txt
echo.
echo -press any key to skip-
timeout /t 2 >nul
goto desk

:lvl2
Cls
type room2.txt
color f
Echo.

exit

:desk
